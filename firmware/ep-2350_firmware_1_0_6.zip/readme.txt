# EP-2350 release log

## upgrading the firmware
1. remove the lower lid.
2. attach a usb-c cable from the device to your computer.
3. press and hold the handle during the entire upgrade process.
4. while still holding the handle, double-click the small button located above the usb port.
5. a drive named "TING BOOT" will appear on your computer. this drive will contain the files INDEX.HTM and INFO_UF2.TXT.
6. drag and drop the firmware file onto this drive.
7. wait for the file to finish transferring.
8. once transferred, the unit will automatically restart (the white led will turn on).

## firmware rev 1.0.6 release notes
  - sample loop glitch fixed
  - json loading regression from 1.0.5 fixed
  - some json parsing errors fixed
  - factory samples are no longer loaded after sleep

## firmware rev 1.0.5 release notes
  - fix of upgrade mode drive name, vid/pid
  - eject drive now reloads samples and settings
  - lowered microphone compared to sample replay
